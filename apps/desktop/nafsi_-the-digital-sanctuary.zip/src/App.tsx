/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import { 
  Zap, 
  Fingerprint, 
  Terminal, 
  Users, 
  TrendingUp, 
  ArrowRight, 
  Menu, 
  ShieldCheck, 
  Brain, 
  Activity, 
  LayoutGrid, 
  User, 
  Plus, 
  Send, 
  Lock, 
  FileText, 
  EyeOff, 
  ScanFace, 
  AlertTriangle,
  Heart,
  Moon,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  ShieldAlert,
  Search,
  MessageCircle,
  Clock,
  Navigation,
  Bolt,
  Filter,
  Globe,
  Calendar,
  Key,
  VenetianMask,
  Cpu,
  BookOpen,
  Wind,
  AreaChart,
  Home,
  Gem,
  CreditCard,
  Trash2,
  Archive,
  Volume2,
  Mic,
  RefreshCcw,
  CheckCircle2,
  LogOut,
  Settings,
  Bell,
  Palette,
  Info,
  BadgeAlert,
  Phone,
  MapPin,
  Stethoscope,
  LifeBuoy,
  X,
  CreditCard as PayIcon,
  Crown,
  RotateCcw
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

// --- TYPES ---
type Module = "onboarding" | "pulse" | "chat" | "mind" | "insights" | "connect" | "emergency" | "me" | "premium";

interface ChatMessageData {
  text: string;
  isAI: boolean;
  time: string;
  sender: string;
  status?: string;
  id: string;
}

interface AppState {
  module: Module;
  subScreen: string;
  hasOnboarded: boolean;
  userData: {
    language: string;
    ageVerified: boolean;
    identityId: string;
    isPremium: boolean;
  };
}

// --- DATABASE: INDEXED DB VAULT ---
const DB_NAME = "NafsiVault";
const STORE_NAME = "neural_logs";

const initDB = () => {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        db.createObjectStore(STORE_NAME, { keyPath: "id" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

const saveLog = async (log: any) => {
  const db = await initDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readwrite");
    tx.objectStore(STORE_NAME).put(log);
    tx.oncomplete = () => resolve(true);
    tx.onerror = () => reject(tx.error);
  });
};

const getLogs = async () => {
  const db = await initDB();
  return new Promise<any[]>((resolve, reject) => {
    const tx = db.transaction(STORE_NAME, "readonly");
    const request = tx.objectStore(STORE_NAME).getAll();
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
};

// --- DESIGN SYSTEM COMPONENTS ---

function Skeleton({ className }: { className?: string }) {
  return <div className={`shimmer rounded-lg ${className}`} />;
}

function EmptyState({ icon, title, desc, actionLabel, onAction }: { icon: React.ReactNode, title: string, desc: string, actionLabel?: string, onAction?: () => void }) {
  return (
    <div className="flex flex-col items-center justify-center p-12 text-center space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-1000">
       <div className="w-20 h-20 glass-panel rounded-full flex items-center justify-center text-slate-700 mb-2">
          {icon}
       </div>
       <div className="space-y-2">
          <h3 className="text-xl font-display font-black text-white uppercase tracking-tight">{title}</h3>
          <p className="text-sm text-slate-500 font-arabic leading-relaxed max-w-[240px]">{desc}</p>
       </div>
       {actionLabel && (
         <button onClick={onAction} className="px-6 py-2 bg-white/5 border border-white/10 rounded-full text-[10px] font-bold uppercase tracking-widest text-pulse-cyan hover:bg-pulse-cyan hover:text-void transition-all">
            {actionLabel}
         </button>
       )}
    </div>
  );
}

// --- APP COMPONENT ---
export default function App() {
  const [state, setState] = useState<AppState>({
    module: "onboarding",
    subScreen: "splash",
    hasOnboarded: false,
    userData: {
      language: "en",
      ageVerified: false,
      identityId: "8821-X",
      isPremium: false
    }
  });

  const setModule = (module: Module, subScreen: string = "main") => {
    setState(prev => ({ ...prev, module, subScreen }));
  };

  const setSubScreen = (subScreen: string) => {
    setState(prev => ({ ...prev, subScreen }));
  };

  const renderModule = () => {
    switch (state.module) {
      case "onboarding": return <OnboardingFlow state={state} setState={setState} />;
      case "pulse": return <PulseModule subScreen={state.subScreen} setSubScreen={setSubScreen} />;
      case "chat": return <ChatModule subScreen={state.subScreen} setSubScreen={setSubScreen} setModule={setModule} />;
      case "mind": return <MindModule subScreen={state.subScreen} setSubScreen={setSubScreen} />;
      case "insights": return <InsightsModule subScreen={state.subScreen} setSubScreen={setSubScreen} />;
      case "connect": return <ConnectModule subScreen={state.subScreen} setSubScreen={setSubScreen} />;
      case "emergency": return <EmergencyModule subScreen={state.subScreen} setSubScreen={setSubScreen} setModule={setModule} />;
      case "me": return <MeModule state={state} setState={setState} />;
      case "premium": return <PremiumModule subScreen={state.subScreen} setSubScreen={setSubScreen} onBack={() => setModule("me")} />;
      default: return <OnboardingFlow state={state} setState={setState} />;
    }
  };

  return (
    <div className="min-h-screen bg-void text-on-surface font-body selection:bg-pulse-cyan/30 overflow-hidden">
      {/* Background Atmosphere */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute inset-0 aurora-mesh opacity-40"></div>
        <div className="absolute top-[10%] left-[5%] w-64 h-64 rounded-full bg-pulse-purple/10 blur-[100px] opacity-30"></div>
        <div className="absolute bottom-[20%] right-[10%] w-96 h-96 rounded-full bg-pulse-cyan/10 blur-[120px] opacity-30"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 flex flex-col h-screen">
        <AnimatePresence mode="wait">
          <motion.main
            key={state.module + state.subScreen}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="flex-1 overflow-hidden"
          >
            {renderModule()}
          </motion.main>
        </AnimatePresence>

        {/* Global Navigation */}
        {state.hasOnboarded && state.module !== "emergency" && (
          <nav className="shrink-0 z-50 bg-[#12121C]/80 backdrop-blur-2xl border-t border-white/5 flex justify-around items-center pt-3 pb-8 px-4 shadow-[0_-10px_40px_rgba(0,0,0,0.5)]">
            <NavItem active={state.module === "mind"} icon={<Brain size={24} />} label="Mind" onClick={() => setModule("mind")} />
            <NavItem active={state.module === "insights"} icon={<TrendingUp size={24} />} label="Data" onClick={() => setModule("insights")} />
            <div className="relative -top-6">
              <div className="absolute inset-0 bg-pulse-cyan blur-xl opacity-20 animate-pulse"></div>
              <button 
                onClick={() => setModule("pulse")}
                className={`w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-90 relative z-10 ${
                  state.module === "pulse" ? "bg-pulse-cyan text-void" : "bg-surface-highest text-pulse-cyan"
                }`}
              >
                <Activity size={32} />
              </button>
              <span className="block text-[10px] text-center font-bold tracking-widest text-slate-500 mt-2 uppercase">Pulse</span>
            </div>
            <NavItem active={state.module === "connect"} icon={<Users size={24} />} label="Nexus" onClick={() => setModule("connect")} />
            <NavItem active={state.module === "me"} icon={<User size={24} />} label="Vault" onClick={() => setModule("me")} />
          </nav>
        )}
      </div>

      {/* Emergency Global Trigger */}
      {state.hasOnboarded && state.module !== "emergency" && (
         <button 
          onClick={() => setModule("emergency")}
          className="fixed bottom-28 left-6 w-12 h-12 glass-panel rounded-full flex items-center justify-center text-pulse-pink shadow-[0_0_20px_rgba(241,91,181,0.2)] z-50 hover:bg-pulse-pink hover:text-white transition-all border border-pulse-pink/20"
        >
          <ShieldAlert size={24} />
        </button>
      )}
    </div>
  );
}

// --- SHARED COMPONENTS ---

function NavItem({ active, icon, label, onClick }: { active: boolean, icon: React.ReactNode, label: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex flex-col items-center justify-center transition-all ${active ? "text-pulse-cyan" : "text-slate-600 hover:text-pulse-purple"}`}>
      <div className="relative">{icon}{active && <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 bg-pulse-cyan rounded-full shadow-[0_0_10px_#00F5D4]" />}</div>
      <span className="font-arabic text-[10px] uppercase font-bold tracking-widest mt-1">{label}</span>
    </button>
  );
}

function Header({ title, leftIcon, onLeftClick, rightIcon, onRightClick, subtitle }: { title: string, leftIcon?: React.ReactNode, onLeftClick?: () => void, rightIcon?: React.ReactNode, onRightClick?: () => void, subtitle?: string }) {
  return (
    <header className="bg-void/60 backdrop-blur-2xl shrink-0 z-50 border-b border-white/10 flex justify-between items-center px-6 py-4">
      <div className="flex items-center gap-4">
        {leftIcon ? <button onClick={onLeftClick} className="text-pulse-cyan">{leftIcon}</button> : <Menu className="text-pulse-cyan opacity-40" />}
        <div className="flex flex-col">
          <h1 className="text-lg font-black tracking-tighter text-pulse-cyan font-display uppercase">{title}</h1>
          {subtitle && <span className="text-[9px] font-bold tracking-widest text-slate-500 uppercase">{subtitle}</span>}
        </div>
      </div>
      {rightIcon && <button onClick={onRightClick} className="w-8 h-8 rounded-full overflow-hidden border border-white/10">{rightIcon}</button>}
    </header>
  );
}

// --- MODULE: ONBOARDING (9 Screens) ---

function OnboardingFlow({ state, setState }: { state: AppState, setState: React.Dispatch<React.SetStateAction<AppState>> }) {
  const next = (s: string) => setState(p => ({ ...p, subScreen: s }));
  const finish = () => setState(p => ({ ...p, module: "pulse", subScreen: "main", hasOnboarded: true }));

  switch (state.subScreen) {
    case "splash": return (
      <div className="h-full flex flex-col items-center justify-center px-8 text-center" onClick={() => next("language")}>
        <motion.div initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} className="mb-8">
           <h1 className="text-8xl md:text-[120px] font-black font-display tracking-tighter text-pulse-cyan neon-glow-cyan">نفسي</h1>
           <h2 className="text-xl font-bold tracking-[0.5em] text-white/20 -mt-2">NAFSI</h2>
        </motion.div>
        <p className="text-slate-400 font-arabic text-lg max-w-xs animate-pulse">Touch the void to begin.</p>
      </div>
    );
    case "language": return (
      <OnboardingStep 
        icon={<Globe size={40} className="text-pulse-cyan" />}
        title="Language & Region"
        desc="Select your sanctuary language. Native Arabic support available by default."
        onNext={() => next("age")}
      >
        <div className="grid grid-cols-2 gap-4 w-full">
           <button className="p-6 glass-panel border-pulse-cyan/40 text-pulse-cyan font-bold">العربية</button>
           <button className="p-6 glass-panel opacity-40">English</button>
           <button className="p-6 glass-panel opacity-40">Français</button>
           <button className="p-6 glass-panel opacity-40">Other</button>
        </div>
      </OnboardingStep>
    );
    case "age": return (
      <OnboardingStep 
        icon={<Calendar size={40} className="text-pulse-purple" />}
        title="Age Verification"
        desc="This sanctuary is for adults. Please verify you are above 18 to proceed with high-precision care."
        onNext={() => next("identity")}
      >
        <div className="flex flex-col items-center gap-6 w-full">
           <div className="text-6xl font-display font-black text-white">1998</div>
           <input type="range" className="w-full accent-pulse-purple" min="1940" max="2008" />
        </div>
      </OnboardingStep>
    );
    case "identity": return (
      <OnboardingStep 
        icon={<ScanFace size={40} className="text-pulse-pink" />}
        title="Anonymous Identity"
        desc="Your data is linked to a private key, not your identity. Here is your generated NeuroID."
        onNext={() => next("biometric")}
      >
        <div className="p-8 glass-panel w-full text-center border-dashed border-pulse-pink/30">
           <span className="text-xs font-mono text-slate-500 uppercase block mb-2">System Generated ID</span>
           <span className="text-3xl font-display font-black text-pulse-pink tracking-widest">NEURAL_ID: 8821-X</span>
        </div>
      </OnboardingStep>
    );
    case "biometric": return (
      <OnboardingStep 
        icon={<Fingerprint size={40} className="text-pulse-cyan" />}
        title="Biometric Setup"
        desc="Enable FaceID or TouchID for rapid, secure access to your sanctuary."
        onNext={() => next("decoy")}
      >
        <button className="p-10 rounded-full glass-panel border-pulse-cyan/20 animate-pulse"><Fingerprint size={60} className="text-pulse-cyan" /></button>
      </OnboardingStep>
    );
    case "decoy": return (
      <OnboardingStep 
        icon={<VenetianMask size={40} className="text-pulse-purple" />}
        title="Decoy Protocol"
        desc="Set a secondary password that opens a clean, decoy version of the app if forced to open it."
        onNext={() => next("keygen")}
      >
        <div className="flex gap-4"><div className="w-12 h-12 glass-panel" /><div className="w-12 h-12 glass-panel" /><div className="w-12 h-12 glass-panel" /><div className="w-12 h-12 glass-panel" /></div>
      </OnboardingStep>
    );
    case "keygen": return (
      <OnboardingStep 
        icon={<Cpu size={40} className="text-pulse-cyan" />}
        title="Encryption Core"
        desc="Generating your local AES-256-GCM vault. This key never leaves your device."
        onNext={() => next("complete")}
      >
        <div className="w-full h-2 bg-surface-low rounded-full overflow-hidden">
          <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 3 }} className="h-full bg-pulse-cyan" />
        </div>
      </OnboardingStep>
    );
    case "complete": return (
      <div className="h-full flex flex-col items-center justify-center p-8 text-center space-y-8">
        <Sparkles size={80} className="text-pulse-cyan animate-bounce" />
        <h1 className="text-4xl font-display font-black tracking-tight">Sanctuary Ready.</h1>
        <p className="text-slate-400 font-arabic">قلبُكَ الآن في مأمن. اضغط للدخول في جلستك الأولى.</p>
        <button onClick={finish} className="w-full py-6 bg-pulse-cyan text-void font-bold text-xl uppercase tracking-widest">Begin First Session</button>
      </div>
    );
    default: return null;
  }
}

function OnboardingStep({ icon, title, desc, children, onNext }: { icon: React.ReactNode, title: string, desc: string, children: React.ReactNode, onNext: () => void }) {
  return (
    <div className="h-full flex flex-col p-8 pt-24 justify-between">
      <div className="space-y-6">
        <div className="w-16 h-16 rounded-xl glass-panel flex items-center justify-center">{icon}</div>
        <h2 className="text-4xl font-display font-black tracking-tight leading-none">{title}</h2>
        <p className="text-slate-400 leading-relaxed font-arabic text-lg">{desc}</p>
        <div className="py-8">{children}</div>
      </div>
      <button onClick={onNext} className="w-full py-5 bg-surface-highest text-white font-bold uppercase tracking-widest flex items-center justify-center gap-3 border border-white/5">
        Continue
        <ArrowRight size={20} />
      </button>
    </div>
  );
}

// --- MODULE: PULSE (Mood & Journaling - 6 Screens) ---

function PulseModule({ subScreen, setSubScreen }: { subScreen: string, setSubScreen: (s: string) => void }) {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadLogs = async () => {
      const logs = await getLogs();
      setHistory(logs.filter(l => l.type === "pulse"));
      setLoading(false);
    };
    if (subScreen === "history") loadLogs();
  }, [subScreen]);

  switch (subScreen) {
    case "main": return (
      <div className="h-full flex flex-col">
        <Header title="Pulse Engine" subtitle="Neural Mapping" />
        <div className="flex-1 flex flex-col items-center justify-center px-8 relative">
           <div className="text-center mb-12">
             <h2 className="font-arabic text-5xl font-bold mb-2">كيف رآسك؟</h2>
             <span className="text-slate-500 uppercase tracking-widest text-[10px]">Tap to Log Frequency</span>
           </div>
           
           <div className="relative w-72 h-72 flex items-center justify-center mb-12" onClick={() => setSubScreen("tags")}>
              <div className="absolute inset-0 bg-pulse-cyan/5 rounded-full blur-3xl animate-pulse"></div>
              <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2" className="text-white/5" />
                <motion.circle initial={{ pathLength: 0 }} animate={{ pathLength: 0.74 }} transition={{ duration: 1.5 }} cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="4" className="text-pulse-cyan" strokeLinecap="round" strokeDasharray="283" />
              </svg>
              <div className="flex flex-col items-center text-center z-10">
                <span className="text-6xl font-display font-black text-pulse-cyan">74</span>
                <span className="text-[10px] uppercase tracking-[0.2em] font-bold text-slate-500">Stability Index</span>
              </div>
           </div>

           <div className="w-full grid grid-cols-2 gap-4">
              <button className="glass-panel p-4 flex flex-col items-center gap-2 group hover:bg-pulse-purple/10" onClick={() => setSubScreen("history")}>
                <Clock className="text-slate-600 group-hover:text-pulse-purple" size={20} />
                <span className="text-[10px] uppercase font-bold tracking-widest">History</span>
              </button>
              <button className="glass-panel p-4 flex flex-col items-center gap-2 group hover:bg-pulse-cyan/10" onClick={() => setSubScreen("insights")}>
                <AreaChart className="text-slate-600 group-hover:text-pulse-cyan" size={20} />
                <span className="text-[10px] uppercase font-bold tracking-widest">Insights</span>
              </button>
           </div>
        </div>
      </div>
    );
    case "tags": return (
      <div className="h-full p-8 flex flex-col justify-between">
        <div>
          <button onClick={() => setSubScreen("main")} className="mb-8 text-pulse-cyan"><ChevronLeft /></button>
          <h2 className="text-4xl font-display font-black tracking-tight mb-2">Context Mapping</h2>
          <p className="text-slate-500 font-arabic mb-8">شنوة اللي مأثر على المورال متاعك اليوم؟</p>
          <div className="flex flex-wrap gap-3">
             {["Work", "Family", "Health", "Social", "Solitude", "Sleep", "Food", "Exercise"].map(tag => (
               <button key={tag} className="px-6 py-3 glass-panel rounded-lg border-white/5 hover:border-pulse-cyan/40 transition-all font-bold uppercase text-[10px] tracking-widest">{tag}</button>
             ))}
          </div>
        </div>
        <button onClick={() => setSubScreen("journal")} className="w-full py-5 bg-pulse-cyan text-void font-bold uppercase tracking-widest">Next</button>
      </div>
    );
    case "journal": return (
      <div className="h-full p-8 flex flex-col">
        <button onClick={() => setSubScreen("tags")} className="mb-8 text-pulse-cyan"><ChevronLeft /></button>
        <h2 className="text-4xl font-display font-black tracking-tight mb-2">Internal Note</h2>
        <p className="text-slate-500 font-arabic mb-8">احكي مع روحك بشوية... No one else will ever see this.</p>
        <textarea className="flex-1 bg-transparent border-0 text-2xl font-arabic outline-none placeholder:text-slate-800" placeholder="عبر هنا..." />
        <button onClick={() => setSubScreen("main")} className="py-5 bg-pulse-purple text-white font-bold uppercase tracking-widest shadow-[0_0_20px_rgba(155,93,229,0.3)] mt-6">Secure Log</button>
      </div>
    );
    case "history": return (
      <div className="h-full flex flex-col">
        <Header title="Neural Timeline" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("main")} />
        <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
           {loading ? (
             <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <React.Fragment key={i}>
                    <Skeleton className="h-20 w-full" />
                  </React.Fragment>
                ))}
             </div>
           ) : history.length === 0 ? (
             <EmptyState 
                icon={<Clock size={40} />} 
                title="Zero Trace Found" 
                desc="No neural pulse logs detected in the local vault. Initialize your first check-in." 
                actionLabel="Log Pulse v1.0"
                onAction={() => setSubScreen("main")}
             />
           ) : (
             <div className="space-y-4">
               {history.map((h, i) => (
                 <motion.div 
                   key={i} 
                   initial={{ opacity: 0, x: -10 }} 
                   animate={{ opacity: 1, x: 0 }} 
                   transition={{ delay: i * 0.1 }}
                   className="p-6 glass-panel flex items-center justify-between group active:scale-[0.98] transition-all" 
                   onClick={() => setSubScreen("detail")}
                 >
                   <div className="flex items-center gap-6">
                      <div className="w-12 h-12 rounded-full border border-pulse-cyan/20 flex items-center justify-center font-display font-black text-pulse-cyan text-xl">
                         {h.data.score || "74"}
                      </div>
                      <div>
                         <h4 className="font-display font-bold uppercase tracking-tight text-on-surface leading-none">{h.data.summary || "Baseline Shift"}</h4>
                         <div className="mt-1 flex items-center gap-2">
                            <div className="w-1 h-1 rounded-full bg-slate-700" />
                            <span className="text-[10px] text-slate-500 uppercase tracking-widest">{new Date(h.timestamp).toLocaleDateString()}</span>
                         </div>
                      </div>
                   </div>
                   <TrendingUp size={20} className="text-slate-700 group-hover:text-pulse-cyan transition-colors" />
                 </motion.div>
               ))}
             </div>
           )}
        </div>
      </div>
    );
    case "detail": return (
      <div className="h-full">
        <Header title="Pulse Detail" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("history")} />
        <div className="p-8 space-y-8">
           <div className="text-center p-12 glass-panel rounded-full aspect-square flex flex-col items-center justify-center mx-auto max-w-[280px]">
              <span className="text-7xl font-display font-black text-pulse-cyan">84</span>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">April 17 Score</span>
           </div>
           <p className="text-lg leading-relaxed text-slate-400 font-arabic border-l-2 border-pulse-cyan pl-4">
             Today reminded me that growth isn't linear. I felt a slight tension in the morning but the grounding exercises helped stabilize my neural patterns.
           </p>
           <button onClick={() => setSubScreen("export")} className="w-full py-4 border border-white/10 text-slate-500 font-bold uppercase tracking-widest text-xs hover:text-pulse-cyan transition-colors">Export Memory</button>
        </div>
      </div>
    );
    case "export": return <ExportScreen onBack={() => setSubScreen("detail")} />;
    default: return null;
  }
}

function ExportScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="h-full flex flex-col p-8 justify-center items-center text-center space-y-8">
       <ShieldCheck size={80} className="text-pulse-cyan" />
       <h2 className="text-3xl font-display font-black tracking-tight uppercase">Encryption Vault Export</h2>
       <p className="text-slate-400 leading-relaxed font-arabic">Preparing your psychological data vault in AES-256 encrypted JSON format.</p>
       <div className="w-full h-1 bg-surface-low rounded-full overflow-hidden">
         <motion.div initial={{ width: 0 }} animate={{ width: "100%" }} transition={{ duration: 2 }} className="h-full bg-pulse-cyan" />
       </div>
       <button onClick={onBack} className="text-slate-500 uppercase font-bold tracking-widest text-xs">Return to Sanctuary</button>
    </div>
  );
}

// --- MODULE: MIND (Grounding & CBT - 6 Screens) ---

function MindModule({ subScreen, setSubScreen }: { subScreen: string, setSubScreen: (s: string) => void }) {
  switch (subScreen) {
    case "main": return (
      <div className="h-full overflow-y-auto pb-32">
        <Header title="Mind Protocols" subtitle="Neural Restoration" />
        <div className="p-6 space-y-8">
           <div className="relative group grayscale hover:grayscale-0 transition-all duration-1000">
              <div className="absolute -inset-1 bg-gradient-to-r from-pulse-cyan to-pulse-purple rounded-xl blur opacity-20 group-hover:opacity-40" />
              <div className="relative glass-panel rounded-xl p-8 overflow-hidden aspect-[16/10] flex flex-col justify-end">
                 <img src="https://picsum.photos/seed/void/800/600" className="absolute inset-0 w-full h-full object-cover opacity-20" referrerPolicy="no-referrer" />
                 <div className="relative z-10">
                    <span className="text-pulse-cyan text-[10px] font-bold uppercase tracking-widest mb-2 block">Protocol 01</span>
                    <h2 className="text-4xl font-display font-black mb-4 tracking-tighter">VOID MEDITATION</h2>
                    <button onClick={() => setSubScreen("breathing")} className="bg-pulse-cyan text-void px-8 py-3 rounded-md font-bold uppercase text-[10px] tracking-widest">Initialize</button>
                 </div>
              </div>
           </div>
           
           <div className="grid grid-cols-2 gap-4">
              <MindActionCard icon={<BookOpen size={24} />} title="CBT Core" onClick={() => setSubScreen("cbt_library")} />
              <MindActionCard icon={<Wind size={24} />} title="Breathwork" onClick={() => setSubScreen("breathing")} />
              <MindActionCard icon={<Navigation size={24} />} title="5-4-3-2-1" onClick={() => setSubScreen("grounding")} />
              <MindActionCard icon={<Activity size={24} />} title="Progress" onClick={() => setSubScreen("progress")} />
           </div>
        </div>
      </div>
    );
    case "cbt_library": return (
      <div className="h-full overflow-y-auto pb-32">
        <Header title="CBT Library" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("main")} />
        <div className="p-6 space-y-4">
           {["Cognitive Distortions", "Thought Records", "Behavioral Activation", "Core Beliefs Shift", "Exposure Protocol"].map(t => (
             <div key={t} className="glass-panel p-6 flex justify-between items-center group hover:border-pulse-purple/30 cursor-pointer" onClick={() => setSubScreen("cbt_player")}>
               <span className="font-display font-bold text-lg">{t}</span>
               <ArrowRight className="text-slate-600 group-hover:text-pulse-purple" />
             </div>
           ))}
        </div>
      </div>
    );
    case "cbt_player": return (
      <div className="h-full p-8 flex flex-col justify-between items-center">
         <div className="w-full flex justify-between"><button onClick={() => setSubScreen("cbt_library")}><X /></button><RefreshCcw size={20} className="text-slate-700" /></div>
         <div className="text-center space-y-6">
            <h2 className="text-[10px] uppercase tracking-widest text-pulse-purple font-bold">CBT Sequence Active</h2>
            <h1 className="text-5xl font-display font-black tracking-tight leading-none uppercase">Identifying Distortions</h1>
            <p className="text-slate-500 font-arabic text-xl leading-relaxed">
               What is the evidence that your catastrophic thought is actually true? Write down 3 cold, hard facts.
            </p>
         </div>
         <button className="w-full py-5 glass-panel text-pulse-purple font-bold uppercase tracking-widest border-pulse-purple/30">Complete Section</button>
      </div>
    );
    case "breathing": return (
      <div className="h-full flex flex-col items-center justify-center p-8 bg-[#050508]">
         <div className="fixed top-8 left-8"><button onClick={() => setSubScreen("main")}><X /></button></div>
         <motion.div 
           animate={{ scale: [1, 1.8, 1], opacity: [0.3, 0.8, 0.3] }} 
           transition={{ duration: 8, repeat: Infinity, ease: "easeInOut" }}
           className="w-48 h-48 rounded-full bg-pulse-cyan blur-3xl"
         />
         <div className="text-center space-y-4 absolute">
            <span className="text-6xl font-display font-black text-white tracking-widest">BREATHE</span>
            <span className="block text-[10px] text-pulse-cyan font-bold tracking-[0.5em] uppercase">Inhale — 4 Seconds</span>
         </div>
         <div className="fixed bottom-12 w-full px-8 text-center"><span className="text-slate-600 uppercase tracking-widest font-bold text-[10px]">Session V01 // Stable Neural Connection</span></div>
      </div>
    );
    case "grounding": return (
      <div className="h-full p-8 flex flex-col justify-between">
         <Header title="5-4-3-2-1" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("main")} />
         <div className="flex-1 flex flex-col justify-center space-y-12">
            <GroundingStep num="5" label="Things you can SEE" />
            <GroundingStep num="4" label="Things you can TOUCH" opacity={0.6} />
            <GroundingStep num="3" label="Things you can HEAR" opacity={0.3} />
         </div>
         <button onClick={() => setSubScreen("main")} className="w-full py-5 bg-pulse-cyan text-void font-bold uppercase tracking-widest">Protocol Complete</button>
      </div>
    );
    case "progress": return (
      <div className="h-full">
        <Header title="Exercise Data" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("main")} />
        <div className="p-8 space-y-8 text-center">
           <Activity size={60} className="mx-auto text-pulse-purple" />
           <h2 className="text-3xl font-display font-black tracking-tight uppercase">Neural Reprogramming Check</h2>
           <div className="text-[120px] font-display font-black text-pulse-purple leading-none tracking-tighter">88%</div>
           <p className="text-slate-500 font-arabic text-lg leading-relaxed">Your consistency in CBT exercises has increased your baseline neuro-stability by 12% this week.</p>
        </div>
      </div>
    );
    default: return null;
  }
}

function ChatMessage({ text, isAI, time, sender, status }: { text: string, isAI?: boolean, time?: string, sender?: string, status?: string }) {
  return (
    <div className={`flex flex-col gap-2 max-w-[85%] ${isAI ? 'items-start' : 'items-end ml-auto'}`}>
      <div className={`p-4 rounded-xl border-white/5 shadow-xl ${isAI ? 'glass-panel rounded-tr-none border-l-4 border-l-pulse-purple' : 'bg-pulse-cyan text-void rounded-tl-none font-medium'}`}>
        <p className="text-sm md:text-base leading-relaxed tracking-wide font-arabic">
          {text}
        </p>
      </div>
      <span className={`text-[10px] font-display tracking-tighter opacity-70 px-1 uppercase ${!isAI ? 'text-pulse-cyan' : 'text-slate-500'}`}>
        {isAI ? `${time} — ${sender}` : status}
      </span>
    </div>
  );
}

function GroundingStep({ num, label, opacity = 1 }: { num: string, label: string, opacity?: number }) {
  return (
    <div className="flex items-center gap-8" style={{ opacity }}>
       <div className="text-8xl font-display font-black text-pulse-cyan">{num}</div>
       <div className="uppercase tracking-widest font-bold text-xs text-slate-400">{label}</div>
    </div>
  );
}

function MindActionCard({ icon, title, onClick }: { icon: React.ReactNode, title: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className="glass-panel p-6 flex flex-col items-center gap-4 transition-all hover:bg-surface-highest group">
       <div className="p-4 bg-white/5 rounded-lg text-slate-500 group-hover:text-pulse-cyan">{icon}</div>
       <span className="font-bold text-[10px] uppercase tracking-widest">{title}</span>
    </button>
  );
}

// --- MODULE: CHAT & AI (8 Screens) ---

function ChatModule({ subScreen, setSubScreen, setModule }: { subScreen: string, setSubScreen: (s: string) => void, setModule: (m: Module, s?: string) => void }) {
  const [messages, setMessages] = useState<ChatMessageData[]>([]);
  const [inputText, setInputText] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isTyping]);

  useEffect(() => {
    const loadChat = async () => {
      const logs = await getLogs();
      const chatLogs = logs.filter(l => l.type === "chat").sort((a: any, b: any) => a.timestamp - b.timestamp);
      if (chatLogs.length > 0) {
        setMessages(chatLogs.map(l => l.data));
      } else {
        setMessages([{
          id: "welcome",
          text: "I am ready to process your thoughts. Any internal conflicts or neural tensions to report?",
          isAI: true,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          sender: "NAFSI"
        }]);
      }
    };
    if (subScreen === "chat") loadChat();
  }, [subScreen]);

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMsg: ChatMessageData = {
      id: Date.now().toString(),
      text: inputText,
      isAI: false,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      sender: "USER",
      status: "SYNCED"
    };

    setMessages(prev => [...prev, userMsg]);
    setInputText("");
    setIsTyping(true);

    // Save to local vault
    saveLog({ id: userMsg.id, type: "chat", data: userMsg, timestamp: Date.now() });

    try {
      const history = messages.map(m => ({
        role: m.isAI ? "model" : "user",
        parts: [{ text: m.text }]
      }));
      history.push({ role: "user", parts: [{ text: inputText }] });

      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ messages: history, context: "User session: Mental stabilization" })
      });

      const data = await res.json();
      
      const aiMsg: ChatMessageData = {
        id: (Date.now() + 1).toString(),
        text: data.text,
        isAI: true,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        sender: "NAFSI"
      };

      setMessages(prev => [...prev, aiMsg]);
      saveLog({ id: aiMsg.id, type: "chat", data: aiMsg, timestamp: Date.now() });

      // Crisis Check (Server side does it too, but we can verify here)
      if (data.text.toLowerCase().includes("emergency protocol") || inputText.toLowerCase().includes("help") || inputText.toLowerCase().includes("انتحار")) {
        setTimeout(() => setModule("emergency"), 2000);
      }

    } catch (e) {
      const errorMsg: ChatMessageData = {
        id: "err",
        text: "Neural link desynced. Re-establishing...",
        isAI: true,
        time: "ERROR",
        sender: "SYSTEM"
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  switch (subScreen) {
    case "main": return (
       <div className="h-full flex flex-col">
          <Header title="Neural Link" subtitle="Secure Session Composer" rightIcon={<RefreshCcw size={16} className="m-auto opacity-40" />} />
          <div className="flex-1 overflow-y-auto p-6 space-y-4">
             <div className="p-6 glass-panel border-pulse-cyan/30 flex items-center justify-between group cursor-pointer" onClick={() => setSubScreen("chat")}>
                <div className="space-y-1">
                   <h4 className="text-pulse-cyan font-display font-bold uppercase tracking-tight">New Cognitive Session</h4>
                   <p className="text-xs text-slate-600">Start a fresh neural analysis layer.</p>
                </div>
                <ArrowRight size={20} className="text-pulse-cyan group-hover:translate-x-1 transition-transform" />
             </div>
             <div className="pt-8"><span className="text-[10px] uppercase font-bold tracking-[0.3em] text-slate-700">Archived Encryptions</span></div>
             <div className="space-y-4 opacity-60">
                <p className="text-[9px] text-slate-500 uppercase font-bold tracking-widest text-center py-8">Historical logs are stored locally in your Neural Vault.</p>
             </div>
          </div>
       </div>
    );
    case "chat": return (
      <div className="h-full flex flex-col relative">
        <Header 
          title="NAFSI CORE" 
          subtitle="Precision V4.2" 
          leftIcon={<ChevronLeft />} 
          onLeftClick={() => setSubScreen("main")} 
          rightIcon={<span className="text-[9px] font-bold text-pulse-cyan m-auto">LIVE</span>}
        />
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-8 bg-[#07070A]">
           {messages.map((m) => (
             <React.Fragment key={m.id}>
               <ChatMessage isAI={m.isAI} text={m.text} time={m.time} sender={m.sender} status={m.status} />
             </React.Fragment>
           ))}
           {isTyping && (
             <div className="flex items-center gap-4 p-4 glass-panel border-pulse-cyan/10 w-fit rounded-xl animate-in fade-in slide-in-from-left-4">
               <div className="flex gap-1">
                 {[0, 1, 2].map((i) => (
                   <motion.div
                     key={i}
                     animate={{ 
                       height: [4, 12, 4],
                       opacity: [0.3, 1, 0.3]
                     }}
                     transition={{
                       duration: 0.8,
                       repeat: Infinity,
                       delay: i * 0.15
                     }}
                     className="w-1 bg-pulse-cyan rounded-full"
                   />
                 ))}
               </div>
               <span className="text-[10px] font-display font-medium uppercase tracking-[0.2em] text-pulse-cyan">ANALYZING NEURAL DATA...</span>
             </div>
           )}
        </div>
        <div className="p-6 pb-32 bg-void border-t border-white/5 flex items-center gap-4">
           <button className="p-3 bg-surface-high rounded-lg text-slate-500"><Mic size={20} /></button>
           <input 
             className="flex-1 bg-surface-low border-b border-white/10 px-0 py-4 font-arabic text-on-surface focus:outline-none focus:border-pulse-cyan transition-all" 
             placeholder="عبر عن نفسك..." 
             value={inputText}
             onChange={(e) => setInputText(e.target.value)}
             onKeyDown={(e) => e.key === "Enter" && handleSendMessage()}
           />
           <button onClick={handleSendMessage} className="p-3 bg-pulse-cyan text-void rounded-lg shadow-lg"><Send size={20} /></button>
        </div>
      </div>
    );
    case "summary": return (
      <div className="h-full p-8 flex flex-col justify-center items-center text-center space-y-8">
         <Sparkles size={60} className="text-pulse-purple" />
         <h2 className="text-3xl font-display font-black tracking-tight uppercase">Session Cognitive Delta</h2>
         <div className="w-full text-right space-y-4">
            <SummaryItem label="Detected Sentiment" value="Neutral-Heavy" color="text-slate-400" />
            <SummaryItem label="Neural Resolution" value="82%" color="text-pulse-cyan" />
            <SummaryItem label="Insight Extraction" value="Completed" color="text-pulse-purple" />
         </div>
         <button onClick={() => setSubScreen("main")} className="w-full py-5 bg-pulse-cyan text-void font-bold uppercase tracking-widest">Seal Session</button>
         <button onClick={() => setSubScreen("main")} className="text-pulse-pink font-bold uppercase text-[10px] tracking-widest">Destroy Trace (Standard Protocol)</button>
      </div>
    );
    default: return null;
  }
}

function SummaryItem({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="flex justify-between items-center border-b border-white/5 py-4">
       <span className="text-[10px] uppercase tracking-widest text-slate-600 font-bold">{label}</span>
       <span className={`font-display font-bold text-lg uppercase ${color}`}>{value}</span>
    </div>
  );
}

// --- MODULE: INSIGHTS (6 Screens) ---

function InsightsModule({ subScreen, setSubScreen }: { subScreen: string, setSubScreen: (s: string) => void }) {
  switch (subScreen) {
    case "main": return (
      <div className="h-full overflow-y-auto pb-32">
        <Header title="Data Engine" subtitle="Neural Insights" />
        <div className="p-6 space-y-6">
           <section className="space-y-4">
             <div className="flex justify-between items-end">
               <h3 className="text-2xl font-display font-black uppercase tracking-tight leading-none text-on-surface">Precision Map</h3>
               <span className="text-[10px] font-bold text-pulse-cyan">LAST 30 DAYS</span>
             </div>
             <div className="glass-panel p-8 aspect-video relative flex items-end">
                <TrendingUp className="absolute top-0 right-0 p-8 text-pulse-cyan opacity-5" size={160} />
                <svg className="w-full h-full overflow-visible" viewBox="0 0 1000 200">
                  <path d="M0,150 L200,120 L400,140 L600,80 L800,100 L1000,40" fill="none" stroke="#00F5D4" strokeWidth="4" strokeLinecap="round" />
                  <circle cx="1000" cy="40" r="6" fill="#00F5D4" />
                </svg>
             </div>
           </section>

           <div className="grid grid-cols-2 gap-4">
              <InsightGridItem title="Wellness Score" value="8.4" meta="+1.2%" onClick={() => setSubScreen("dashboard")} />
              <InsightGridItem title="Sync Time" value="12h" meta="Total" onClick={() => setSubScreen("trends")} />
           </div>

           <div className="glass-panel p-6 border-pulse-purple/30 group cursor-pointer" onClick={() => setSubScreen("ai_insights")}>
              <div className="flex items-center gap-4 mb-4">
                 <Sparkles className="text-pulse-purple" size={20} />
                 <h4 className="font-display font-black uppercase tracking-tight text-pulse-purple">AI Synthesis Ready</h4>
              </div>
              <p className="text-sm text-slate-400 font-arabic leading-relaxed mb-4">
                 Your neural patterns show a strong correlation between social interactions and evening stress levels. Recommendation: Deep Breath Protocol at 6 PM.
              </p>
              <ArrowRight className="text-pulse-purple ml-auto group-hover:translate-x-1 transition-transform" />
           </div>
        </div>
      </div>
    );
    case "dashboard": return <div className="p-8">Dashboard Overview Component... <button onClick={() => setSubScreen("main")}>Back</button></div>;
    case "trends": return <div className="p-8">Trend Analysis Component... <button onClick={() => setSubScreen("main")}>Back</button></div>;
    case "ai_insights": return (
      <div className="h-full p-8 flex flex-col pt-24 bg-[#0a0a0f]">
         <div className="fixed top-8 left-8"><button onClick={() => setSubScreen("main")}><X /></button></div>
         <Sparkles size={60} className="text-pulse-purple mb-8 animate-pulse" />
         <h2 className="text-4xl font-display font-black tracking-tight mb-8 leading-none">AI CORE SYNTHESIS</h2>
         <div className="space-y-8 flex-1 overflow-y-auto pr-4 no-scrollbar">
            <InsightPoint title="Cortisol Loop" desc="We detected a recurring peak at 11:30 AM. This aligns with your work schedule. Your heart rate variability dropped by 18%." />
            <InsightPoint title="Growth Gradient" desc="Despite stress peaks, your emotional regulation exercises are 24% more effective than last month." />
            <InsightPoint title="Recommended Shift" desc="Redirect focus to Cognitive Distortions during morning peaks to achieve 90% stability." />
         </div>
      </div>
    );
    default: return null;
  }
}

function InsightPoint({ title, desc }: { title: string, desc: string }) {
  return (
    <div className="space-y-2 border-l-2 border-pulse-purple/30 pl-6 py-2">
       <h4 className="font-display font-bold uppercase tracking-widest text-pulse-purple text-xs">{title}</h4>
       <p className="text-slate-400 font-arabic text-lg leading-relaxed">{desc}</p>
    </div>
  );
}

function InsightGridItem({ title, value, meta, onClick }: { title: string, value: string, meta: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className="glass-panel p-6 text-left hover:border-white/20 transition-all">
       <span className="text-[10px] uppercase tracking-widest text-slate-500 font-bold mb-1 block">{title}</span>
       <div className="flex items-baseline gap-2">
          <span className="text-3xl font-display font-black text-white">{value}</span>
          <span className="text-xs font-bold text-pulse-cyan">{meta}</span>
       </div>
    </button>
  );
}

// --- MODULE: CONNECT (6 Screens) ---

function ConnectModule({ subScreen, setSubScreen }: { subScreen: string, setSubScreen: (s: string) => void }) {
  const [connecting, setConnecting] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setConnecting(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  switch (subScreen) {
    case "main": return (
      <div className="h-full overflow-y-auto pb-32">
        <Header title="The Nexus" subtitle="Anonymous Collective" />
        <div className="p-6 space-y-8">
           <section>
             <h3 className="text-[10px] uppercase tracking-[0.3em] font-bold text-slate-700 mb-4 px-2">Live Sanctuary Rooms</h3>
             <div className="grid grid-cols-1 gap-4">
                {connecting ? (
                   [...Array(3)].map((_, i) => (
                    <React.Fragment key={i}>
                      <Skeleton className="h-28 w-full" />
                    </React.Fragment>
                   ))
                ) : (
                  <>
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
                      <RoomCard title="Tech Burnout" active={12} type="Work" color="text-pulse-cyan" onClick={() => setSubScreen("room")} />
                    </motion.div>
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
                      <RoomCard title="Mindful Silence" active={45} type="Growth" color="text-pulse-purple" onClick={() => setSubScreen("room")} />
                    </motion.div>
                    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
                      <RoomCard title="Crisis Sync" active={3} type="Safety" color="text-pulse-pink" onClick={() => setSubScreen("room")} />
                    </motion.div>
                  </>
                )}
             </div>
           </section>
           
           <button onClick={() => setSubScreen("create")} className="w-full py-5 glass-panel flex items-center justify-center gap-3 border-dashed border-white/10 group hover:border-pulse-cyan/40">
              <Plus className="text-slate-600 group-hover:text-pulse-cyan" />
              <span className="font-bold text-xs uppercase tracking-widest">Construct New Space</span>
           </button>
        </div>
      </div>
    );
    case "room": return (
      <div className="h-full flex flex-col relative bg-[#050508]">
        <Header title="ANONYMOUS_VOID" subtitle="12 PEERS SYNCED" leftIcon={<ChevronLeft />} onLeftClick={() => setSubScreen("main")} />
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
           <div className="text-center py-8"><span className="text-[9px] uppercase tracking-widest text-slate-800 font-bold bg-white/5 py-1 px-4 rounded-full">Encrypted P2P Nexus Protocol Active</span></div>
           <RoomMessage user="GHOST_44" text="Today was the hardest day in a while, but I'm trying to stay present." />
           <RoomMessage user="VOID_USER" text="We see you. Remember the 5-4-3-2-1 protocol if the tension peaks." />
           <RoomMessage user="PULSE_88" text="Is anyone else finding the evening sessions helpful?" isOwn />
        </div>
        <div className="p-6 pb-24 flex items-center gap-4">
           <input className="flex-1 bg-surface-low border-b border-white/5 px-0 py-4 font-arabic text-on-surface focus:outline-none focus:border-pulse-cyan" placeholder="Transmit thought..." />
           <button className="p-3 bg-pulse-cyan text-void rounded-lg"><Send size={20} /></button>
        </div>
      </div>
    );
    case "create": return <div className="p-8">Create Room Component... <button onClick={() => setSubScreen("main")}>Back</button></div>;
    default: return null;
  }
}

function RoomMessage({ user, text, isOwn }: { user: string, text: string, isOwn?: boolean }) {
  return (
    <div className={`flex flex-col gap-1 max-w-[80%] ${isOwn ? 'ml-auto items-end' : 'items-start'}`}>
       <span className="text-[10px] font-mono tracking-widest text-slate-700 font-bold uppercase">{user}</span>
       <div className={`p-4 rounded-xl border border-white/5 ${isOwn ? 'bg-pulse-cyan text-void font-bold shadow-[0_0_15px_rgba(0,245,212,0.2)]' : 'glass-panel text-slate-300'}`}>
          <p className="text-sm font-arabic leading-relaxed">{text}</p>
       </div>
    </div>
  );
}

function RoomCard({ title, active, type, color, onClick }: { title: string, active: number, type: string, color: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className="glass-panel p-6 flex items-center justify-between group hover:bg-surface-high transition-all border-white/5">
       <div className="space-y-1">
          <span className={`text-[10px] uppercase font-black tracking-widest ${color}`}>{type}</span>
          <h4 className="text-2xl font-display font-black text-on-surface tracking-tighter uppercase">{title}</h4>
       </div>
       <div className="flex flex-col items-end gap-1">
          <div className="flex -space-x-1">
             {[...Array(3)].map((_, i) => <div key={i} className="w-5 h-5 rounded-full bg-slate-800 border-2 border-void" />)}
          </div>
          <span className="text-[9px] font-bold text-slate-600 uppercase tracking-widest">{active} SYNCED</span>
       </div>
    </button>
  );
}

// --- MODULE: EMERGENCY (5 Screens) ---

function EmergencyModule({ subScreen, setSubScreen, setModule }: { subScreen: string, setSubScreen: (s: string) => void, setModule: (m: Module, s?: string) => void }) {
  const onBack = () => setModule("pulse");

  return (
    <div className="h-full flex flex-col relative bg-[#090505]">
       <div className="absolute inset-0 bg-pulse-pink/5 animate-pulse pointer-events-none" />
       <Header title="CRITICAL MODE" subtitle="Emergency Protocol Active" leftIcon={<X />} onLeftClick={onBack} />
       <div className="flex-1 overflow-y-auto p-8 space-y-8 flex flex-col">
          <div className="text-center space-y-4 mb-8">
             <BadgeAlert size={80} className="mx-auto text-pulse-pink animate-ping" />
             <h2 className="text-5xl font-display font-black text-white tracking-tighter uppercase font-arabic leading-none">أنت لست وحدك.</h2>
             <p className="text-slate-400 font-arabic text-xl leading-relaxed">System has detected high neural distress. Select an immediate protocol.</p>
          </div>
          
          <div className="space-y-4">
             <EmergencyAction title="Direct Help: 190" desc="Call immediate medical emergency support." icon={<Phone />} color="bg-pulse-pink" />
             <EmergencyAction title="Crisis Counselor" desc="Talk to a secure human escalation agent (Anonymously)." icon={<Stethoscope />} color="bg-surface-high" />
             <EmergencyAction title="Grounding Protocol" desc="Initialize immediate V1 neural stabilization." icon={<LifeBuoy />} color="bg-surface-low" onClick={() => setModule("mind", "grounding")} />
             <EmergencyAction title="Safety Plan" desc="Review your pre-constructed escape and safety plan." icon={<MapPin />} color="bg-void border border-pulse-pink/20" />
          </div>
       </div>
       <div className="p-8 text-center"><span className="text-[9px] font-mono font-bold text-pulse-pink/40 uppercase tracking-[0.3em]">NAFSI CRISIS LAYER V4.0 // SECURE LINK ACTIVE</span></div>
    </div>
  );
}

function EmergencyAction({ title, desc, icon, color, onClick }: { title: string, desc: string, icon: React.ReactNode, color: string, onClick?: () => void }) {
  return (
    <button onClick={onClick} className={`w-full p-6 ${color} rounded-xl flex items-center justify-between group transition-all active:scale-[0.98] border border-white/5`}>
       <div className="flex items-center gap-6">
          <div className="w-14 h-14 glass-panel flex items-center justify-center text-white">{icon}</div>
          <div className="text-left">
             <h4 className="text-xl font-display font-black text-white uppercase font-arabic leading-none">{title}</h4>
             <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest mt-1">{desc}</p>
          </div>
       </div>
       <ArrowRight className="text-white opacity-40 group-hover:opacity-100 transition-opacity" />
    </button>
  );
}

// --- MODULE: ME (Profile & Vault - 8 Screens) ---

function MeModule({ state, setState }: { state: AppState, setState: React.Dispatch<React.SetStateAction<AppState>> }) {
  const setSub = (s: string) => setState(p => ({ ...p, subScreen: s }));
  const setMod = (m: Module, s: string = "main") => setState(p => ({ ...p, module: m, subScreen: s }));

  switch (state.subScreen) {
    case "main": return (
      <div className="h-full overflow-y-auto pb-32">
        <Header title="Neural Vault" subtitle="IDENTITY & SECURITY" rightIcon={<RefreshCcw size={16} className="m-auto opacity-40" />} />
        <div className="p-8 pt-12 flex flex-col items-center">
           <div className="relative w-40 h-40 mb-8 border-2 border-pulse-cyan/20 p-2 rounded-full overflow-hidden">
              <div className="absolute inset-0 bg-pulse-cyan/5 blur-2xl animate-pulse" />
              <div className="w-full h-full glass-panel rounded-full flex items-center justify-center bg-void">
                 <Fingerprint size={80} className="text-pulse-cyan opacity-40" />
              </div>
              <div className="absolute bottom-1 right-1/2 translate-x-1/2 px-2 py-0.5 bg-pulse-cyan text-void text-[8px] font-bold rounded-full uppercase tracking-tighter">SECURE</div>
           </div>
           <h2 className="text-3xl font-display font-black tracking-tight text-white uppercase mb-2">NEURAL_ID: {state.userData.identityId}</h2>
           <div className="flex gap-2">
              <span className="px-3 py-1 bg-surface-low text-[8px] font-bold text-slate-500 uppercase tracking-widest rounded-full">{state.userData.isPremium ? "PREMIUM CORE" : "STANDARD CORE"}</span>
              <span className="px-3 py-1 bg-surface-low text-[8px] font-bold text-pulse-cyan uppercase tracking-widest rounded-full">ENCRYPTED</span>
           </div>
        </div>

        {!state.userData.isPremium && (
          <div className="px-6 mb-8">
            <button onClick={() => setMod("premium")} className="w-full p-6 rounded-xl bg-gradient-to-r from-pulse-cyan to-pulse-purple flex items-center justify-between group">
               <div className="flex items-center gap-4 text-void">
                  <Crown size={24} className="animate-pulse" />
                  <div className="text-left leading-none">
                     <span className="block text-[10px] font-black uppercase tracking-widest opacity-80">Evolution Required</span>
                     <h3 className="text-xl font-display font-black uppercase">Sanctuary Premium</h3>
                  </div>
               </div>
               <ArrowRight className="text-void" />
            </button>
          </div>
        )}

        <div className="px-6 space-y-4">
           <div className="pt-8 pb-4 flex justify-between items-center">
              <span className="text-[10px] uppercase font-black tracking-[0.3em] text-slate-700">Recent Neural Sessions</span>
              <button 
                onClick={() => setSub("data_mgmt")} 
                className="text-[9px] font-bold text-pulse-cyan uppercase tracking-widest border-b border-pulse-cyan/20 pb-0.5 hover:border-pulse-cyan transition-all"
              >
                Expand All
              </button>
           </div>
           
           <div className="space-y-4">
              <div className="space-y-3">
                 <Skeleton className="h-16 w-full opacity-60" />
                 <Skeleton className="h-16 w-full opacity-40" />
              </div>
              <div className="text-center py-6">
                 <p className="text-[9px] text-slate-700 uppercase font-bold tracking-widest mb-4">No recent cloud-synced sessions. All data is pinned to your local vault.</p>
                 <ShieldCheck className="mx-auto text-slate-800" size={20} />
              </div>
           </div>

           <div className="pt-8"><span className="text-[10px] uppercase font-black tracking-[0.3em] text-slate-700">General Security</span></div>
           <SettingsItem icon={<ShieldCheck size={18} />} title="Security Protocols" desc="Key rotation, Decoy password, Biometrics." onClick={() => setSub("security")} />
           <SettingsItem icon={<Globe size={18} />} title="Region & Language" desc="Current: العربية / Arabic" onClick={() => setSub("region")} />
           <SettingsItem icon={<Bell size={18} />} title="Neural Alerts" desc="Configure sanctuary pings and crisis alerts." onClick={() => setSub("notifications")} />
           <SettingsItem icon={<Palette size={18} />} title="Sanctuary Theme" desc="Void Mode (Dark Default)" onClick={() => setSub("appearance")} />
           <SettingsItem icon={<LifeBuoy size={18} />} title="Data Management" desc="Export vault, Data destruction, Portability." onClick={() => setSub("data_mgmt")} />
           <SettingsItem icon={<Info size={18} />} title="About NAFSI" desc="Privacy manifesto, License, Terms." onClick={() => setSub("about")} />
           <button onClick={() => setState(p => ({ ...p, module: "onboarding", subScreen: "splash", hasOnboarded: false }))} className="w-full p-6 glass-panel border-pulse-pink/10 text-pulse-pink font-bold uppercase tracking-widest text-[10px] flex items-center justify-between group">
              <span>Destroy Session Link</span>
              <LogOut size={16} className="group-hover:translate-x-1 transition-all" />
           </button>
        </div>
      </div>
    );
    case "security": return <div className="p-8">Security Configuration... <button onClick={() => setSub("main")}>Back</button></div>;
    case "region": return <div className="p-8">Region & Language Settings... <button onClick={() => setSub("main")}>Back</button></div>;
    case "notifications": return <div className="p-8">Notification Preferences... <button onClick={() => setSub("main")}>Back</button></div>;
    case "appearance": return <div className="p-8">Appearance & Custom Colors... <button onClick={() => setSub("main")}>Back</button></div>;
    case "data_mgmt": return <div className="p-8">Data Vault Management... <button onClick={() => setSub("main")}>Back</button></div>;
    case "about": return <div className="p-8">About Nafsi & Legal... <button onClick={() => setSub("main")}>Back</button></div>;
    default: return null;
  }
}

function SettingsItem({ icon, title, desc, onClick }: { icon: React.ReactNode, title: string, desc: string, onClick: () => void }) {
  return (
    <button onClick={onClick} className="w-full flex items-center justify-between p-6 bg-surface-low rounded-lg border border-white/5 hover:border-white/10 group transition-all">
       <div className="flex items-center gap-4">
          <div className="p-3 bg-void rounded-lg text-slate-500 group-hover:text-pulse-cyan">{icon}</div>
          <div className="text-left">
             <h4 className="font-display font-bold text-on-surface uppercase leading-none mb-1">{title}</h4>
             <p className="text-[10px] text-slate-600 uppercase font-bold tracking-widest">{desc}</p>
          </div>
       </div>
       <ChevronRight size={18} className="text-slate-800 group-hover:text-white" />
    </button>
  );
}

// --- MODULE: PREMIUM (Monetization - 4 Screens) ---

function PremiumModule({ subScreen, setSubScreen, onBack }: { subScreen: string, setSubScreen: (s: string) => void, onBack: () => void }) {
  switch (subScreen) {
    case "main": return (
      <div className="h-full flex flex-col p-8 bg-gradient-to-b from-pulse-purple/10 to-void relative pt-24 overflow-y-auto pb-24">
         <div className="fixed top-8 left-8"><button onClick={onBack}><X /></button></div>
         <div className="text-center space-y-6 mb-12">
            <Crown size={80} className="mx-auto text-pulse-purple animate-pulse" />
            <h2 className="text-5xl font-display font-black tracking-tight text-white uppercase leading-none">SANCTUARY PREMIUM</h2>
            <p className="text-slate-400 font-arabic text-xl leading-relaxed">Evolve your care with total precision tools and limitless cognitive Link sessions.</p>
         </div>
         
         <div className="space-y-4 mb-12">
            <PremiumPerk icon={<Sparkles />} text="Infinite AI Session Layers" />
            <PremiumPerk icon={<ShieldCheck />} text="Biometric Lockdown Plus" />
            <PremiumPerk icon={<Activity />} text="Advanced Neural Predictive Analysis" />
            <PremiumPerk icon={<Key />} text="Multiple Identity Layers" />
         </div>

         <div className="grid grid-cols-1 gap-4">
            <button className="glass-panel p-8 rounded-2xl border-pulse-purple/40 bg-surface-high/50 text-center space-y-2 group" onClick={() => setSubScreen("payment")}>
               <span className="text-[10px] font-black uppercase text-pulse-purple tracking-widest">Yearly Commitment</span>
               <div className="text-4xl font-display font-black text-white">$149.99<span className="text-lg opacity-40">/yr</span></div>
               <span className="block text-[10px] font-bold text-slate-500 uppercase">Save 40% — Limited Time</span>
            </button>
            <button className="glass-panel p-8 rounded-2xl border-white/5 text-center space-y-2" onClick={() => setSubScreen("payment")}>
               <span className="text-[10px] font-black uppercase text-slate-600 tracking-widest">Monthly Core</span>
               <div className="text-4xl font-display font-black text-white">$19.99<span className="text-lg opacity-40">/mo</span></div>
            </button>
         </div>
      </div>
    );
    case "payment": return (
      <div className="h-full p-8 flex flex-col pt-24 space-y-8">
         <div className="fixed top-8 left-8"><button onClick={() => setSubScreen("main")}><ChevronLeft /></button></div>
         <h2 className="text-3xl font-display font-black tracking-tight uppercase">SECURE PAYMENT</h2>
         <div className="space-y-6">
            <div className="p-6 glass-panel flex flex-col gap-4">
               <div className="flex justify-between items-center bg-void p-4 border border-white/5 rounded-lg">
                  <PayIcon className="text-slate-600" />
                  <span className="font-mono text-slate-400">.... .... .... 4421</span>
               </div>
               <button 
                className="py-4 bg-pulse-purple text-white font-bold uppercase tracking-widest shadow-lg relative overflow-hidden group"
                onClick={() => setSubScreen("activating")}
               >
                 <div className="absolute inset-0 shimmer opacity-20 group-hover:opacity-40 transition-opacity" />
                 <span className="relative z-10 transition-transform group-active:scale-95">Finalize Activation</span>
               </button>
            </div>
            <p className="text-center text-[9px] text-slate-700 uppercase tracking-widest">Encrypted via Stripe Neural Gateway</p>
         </div>
      </div>
    );
    case "activating": return (
      <div className="h-full flex flex-col items-center justify-center p-12 text-center space-y-12">
         <div className="relative">
            <RotateCcw size={80} className="text-pulse-purple animate-spin" />
            <div className="absolute inset-0 blur-3xl bg-pulse-purple/20 animate-pulse" />
         </div>
         <div className="space-y-4">
            <h2 className="text-3xl font-display font-black uppercase tracking-tighter">SECURE ACTIVATION</h2>
            <p className="text-slate-500 font-arabic text-xl leading-relaxed">System is provisioning your Premium Tier Neural Layers. Re-keying encryption vault...</p>
         </div>
         <div className="w-full max-w-[200px] h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
               initial={{ width: 0 }} 
               animate={{ width: "100%" }} 
               transition={{ duration: 4 }} 
               onAnimationComplete={() => onBack()}
               className="h-full bg-pulse-purple" 
            />
         </div>
         <span className="text-[10px] font-mono text-pulse-purple/60 uppercase tracking-[0.4em]">VAULT_REGEN_01</span>
      </div>
    );
    default: return null;
  }
}

function PremiumPerk({ icon, text }: { icon: React.ReactNode, text: string }) {
  return (
    <div className="flex items-center gap-4 group">
       <div className="text-pulse-cyan group-hover:scale-110 transition-transform">{icon}</div>
       <span className="text-sm font-bold text-slate-300 uppercase tracking-tight">{text}</span>
    </div>
  );
}

// --- MOCK COMPONENTS (PLACEHOLDERS REPLACED BY FLOWS) ---
// Note: HomeScreen is now handled by the Onboarding logic once 'hasOnboarded' is true.
